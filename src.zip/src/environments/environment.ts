export const environment = {
  production: false,
  firebase:{
    apiKey: "AIzaSyBvderGyKp69bQPXdgwWO7xMHXn7Ncowig",
    authDomain: "manup-20d69.firebaseapp.com",
    databaseURL: "https://manup-20d69.firebaseio.com",
    projectId: "manup-20d69",
    storageBucket: "manup-20d69.appspot.com",
    messagingSenderId: "532999918502"
  }
};
