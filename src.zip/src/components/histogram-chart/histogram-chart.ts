import {
  Component, Input, OnChanges, ViewChild,
  ElementRef
} from '@angular/core';

import * as d3 from 'd3';
import * as _ from 'lodash';

/**
 * Generated class for the HistogramChartComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'histogram-chart',
  templateUrl: 'histogram-chart.html'
})
export class HistogramChartComponent implements OnChanges {
  @Input() data;
  @ViewChild('histogramChart') private chartContainer: ElementRef;


  text: string;
  private graph;

  constructor() {
    console.log('Hello HistogramChartComponent Component');
  }

  ngOnChanges() {

    if (!this.graph) {
      this.graph = this.createChart();
      if (this.data) {
        this.graph.update(this.data);
      }
    }

    if (this.graph) {
      this.graph.update(this.data);
    }

  }

  createChart() {
    const self = this;
    let width = self.chartContainer.nativeElement.offsetWidth;
    let height = self.chartContainer.nativeElement.offsetHeight;
    const margin = {
      top: 0.05 * height,
      right: 0.05 * width,
      bottom: 0.25 * height,
      left: 0.1 * width
    };

    let graphWidth = width - margin.left - margin.right;
    let graphHeight = height - margin.top - margin.bottom;
    const canvas = d3
      .select('div.histogramChart')
      .append('svg')
      .attr('viewBox', `0, 0, ${width}, ${height}`)
      .attr('preserveAspectRatio', 'xMidYMid meet');
    const eleGroup = canvas
      .append('g')
      .attr('class', 'eleGroup')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);

    const xScale = d3.scaleLinear().rangeRound(<any>[0, graphWidth]);

    const yScale = d3.scaleLinear().range(<any>[graphHeight, 0]);

    const xAxis = eleGroup
      .append('g')
      .attr('class', 'x axis')
      .attr('transform', `translate(0, ${graphHeight})`);

    const yAxis = eleGroup.append('g').attr('class', 'y axis');



    const formatCount = d3.format(",.0f");

    function update(rawData){


      let data = _.cloneDeep(rawData.map(d=>d.value));

      xScale.domain(d3.extent(data) as any);

      xAxis
        .call(d3.axisBottom(xScale).tickFormat(formatCount))
        .selectAll('text')
        .style('text-anchor', 'start')
        .style('font-size', '10px')
        .attr('dx', '-.8em')
        .attr('dy', '.15em');

      const bins = d3.histogram()
        .domain(xScale.domain() as any)
        // .thresholds(d3.range(xScale.domain()[0], xScale.domain()[1], (xScale.domain()[1]-xScale.domain()[0])/10) as any)(data);
        .thresholds(d3.range(xScale.domain()[0], xScale.domain()[1], 5) as any)(data);


      yScale.domain([0, d3.max(bins, function(d) { return d.length; })]);
      yAxis
        .call(d3.axisLeft(yScale).ticks(5))
        .selectAll('text')
        .style('font-size', '10px');

      let bars = eleGroup
        .selectAll('rect');

      // bars
      //   .attr("x", (d:any) => xScale(d.x0))
      //   .attr("width", xScale(bins[0].x1) - xScale(bins[0].x0))
      //   .attr("height", function(d: any) { return graphHeight - yScale(d.length); })
      //   .attr("transform", function(d: any) { return "translate( 0" + "," + yScale(d.length) + ")"; });

      console.log(bins);
      bars.data(bins).enter().append('g')
        .attr('class', 'bar')
        .append('rect')
        .attr("x", (d:any) => xScale(d.x0))
        .attr("width", xScale(bins[0].x1) - xScale(bins[0].x0))
        .merge(bars as any)
        .attr("height", function(d: any) { return graphHeight - yScale(d.length); })
        .attr("transform", function(d: any) { return "translate( 0" + "," + yScale(d.length) + ")"; });

      bars.exit().remove();



    }

    return {
      update: update
    };
  }

}
