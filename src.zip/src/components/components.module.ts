import { NgModule } from '@angular/core';
import { LineChartComponent } from './line-chart/line-chart';
import { HistogramChartComponent } from './histogram-chart/histogram-chart';

@NgModule({
	declarations: [LineChartComponent,
    HistogramChartComponent],
	imports: [],
	exports: [LineChartComponent,
    HistogramChartComponent]
})
export class ComponentsModule {}
