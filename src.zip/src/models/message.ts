export interface Message {
  userId: string;
  content: string;
  timeStamp: number;
  liked: {
    userId: boolean;
  }
  loved: {
    userId: boolean;
  }
}
