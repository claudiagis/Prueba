export interface Chat {
  userId: string;
  userName?: string;
  content: string;
  timeStamp: number;
  specialMessage?: boolean;
}
