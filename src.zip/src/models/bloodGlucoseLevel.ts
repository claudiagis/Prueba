export interface BloodGlucoseLevel {
  userId: string;
  value: number;
  timeStamp: number;
}
