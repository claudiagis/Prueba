import {Injectable, OnDestroy} from '@angular/core';
import {AngularFireAuth} from "angularfire2/auth";
import {AngularFireDatabase} from "angularfire2/database";
import * as firebase from 'firebase/app';
import {Subscription} from "rxjs/Subscription";

@Injectable()
export class FirebaseServiceProvider implements OnDestroy{

  // authState: Observable<firebase.User>;
  authState: any;
  user: firebase.User;
  userName: string;
  userNameSubscription: Subscription;
  constructor(private afAuth: AngularFireAuth,
              public afd: AngularFireDatabase) {
    this.authState = afAuth.authState;
    this.authState.subscribe(user => {
      this.user = user;
      if (user){
        this.userNameSubscription = this.afd.object('/userProfile/'+user.uid).valueChanges().subscribe((data: any) => {
          this.userName = data.name;
        })
      }else{
        if(this.userNameSubscription){

          this.userNameSubscription.unsubscribe()
        }
      }
    });
  }
  ngOnDestroy() {

  }
  signUp(email, password, name) {
    return this.afAuth.auth.createUserWithEmailAndPassword(email, password)
      .then(newUser => {
        const user = newUser.user;
        this.afd.list('/userProfile').update(user.uid,
          {email: email, name: name});
      })
  }

  signIn(email, password) {
    return this.afAuth.auth.signInWithEmailAndPassword(email, password);
  }

  signOut() {
    return this.afAuth.auth.signOut();
  }

  resetPassword(email) {
    return this.afAuth.auth.sendPasswordResetEmail(email);
  }


  // creageNewList(name) {
  //   return this.afd.list('/bglValues').push({
  //     name: name,
  //     creator: this.user.email
  //   });
  // }
  //
  // getUserLists() {
  //   return this.afd.list('/bglValues', ref => {
  //     return ref.equalTo(this.user.email).orderByChild('creator');
  //   })
  // }

}
