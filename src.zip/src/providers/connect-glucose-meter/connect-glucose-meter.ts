import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Subject} from "rxjs/Subject";
import {Observable} from "rxjs/Observable";

/*
  Generated class for the ConnectGlucoseMeterProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ConnectGlucoseMeterProvider {
  private bglValue: any;
  private bglSubject: Subject<any> = new Subject<any>();
  public readonly bglObservable$: Observable<any> = this.bglSubject.asObservable();
  constructor(public http: HttpClient) {
    console.log('Hello ConnectGlucoseMeterProvider Provider');
  }

  setBglValue(value){
    this.bglValue = value;
    this.bglSubject.next(this.bglValue);
  }

}
