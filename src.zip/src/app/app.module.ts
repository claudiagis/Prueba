import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { AngularFireModule } from 'angularfire2';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { Firebase } from '@ionic-native/firebase';

import { environment } from '../environments/environment';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { AngularFireDatabaseModule } from "angularfire2/database";
import { FirebaseServiceProvider } from '../providers/firebase-service/firebase-service';
import { HttpClientModule } from "@angular/common/http";
import { BLE } from "@ionic-native/ble";
import { ConnectGlucoseMeterProvider } from '../providers/connect-glucose-meter/connect-glucose-meter';
import { FcmProvider } from '../providers/fcm/fcm';

const firebase = {
  apiKey: "AIzaSyAOPXIkCAes127seIZm6f2kJXPvMgsJNOM",
  authDomain: "appmanup.firebaseapp.com",
  databaseURL: "https://appmanup.firebaseio.com",
  projectId: "appmanup",
  storageBucket: "appmanup.appspot.com",
  messagingSenderId: "364729202691"
}

@NgModule({
  declarations: [
    MyApp
  ],
  imports: [
    BrowserModule,
    AngularFireModule.initializeApp(environment.firebase),
    HttpClientModule,
    AngularFireAuthModule, // imports firebase/auth, only needed for auth features,
    AngularFireDatabaseModule,
    AngularFirestoreModule,
    IonicModule.forRoot(MyApp, {
      scrollPadding: false,
      scrollAssist: true,
      autoFocusAssist: false
    }),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    FirebaseServiceProvider,
    BLE,
    ConnectGlucoseMeterProvider,
    Firebase,
    FcmProvider
  ]
})
export class AppModule {}
