import {Component, NgZone} from '@angular/core';
import {AlertController, IonicPage, NavController, NavParams, ToastController} from 'ionic-angular';
import {FirebaseServiceProvider} from "../../providers/firebase-service/firebase-service";
import {BloodGlucoseLevel} from "../../models/bloodGlucoseLevel";

// for real device
import {BLE} from "@ionic-native/ble";
import * as _ from 'lodash';
import {ConnectGlucoseMeterProvider} from "../../providers/connect-glucose-meter/connect-glucose-meter";
import {Subscription} from "rxjs/Subscription";

/**
 * Generated class for the ConnectPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-connect',
  templateUrl: 'connect.html',
})
export class ConnectPage {

  devices: any[] = [];
  statusMessage: string;
  result: any;
  subscriptions: Subscription[] = [];

  constructor(public navCtrl: NavController, public navParams: NavParams,
              public firebaseService: FirebaseServiceProvider,
              public alertCtrl: AlertController,
              public toastCtrl: ToastController,
              private ble: BLE,
              private ngZone: NgZone,
              private connectService: ConnectGlucoseMeterProvider) {
    this.subscriptions.push(this.connectService.bglObservable$.subscribe((data) => {
      this.result = data;
      this.addBgl(this.result);
    }));
  }

  signOut() {
    this.firebaseService.signOut().then(() => {
      this.navCtrl.setRoot('LoginPage');
    })
  }

  addBgl(value) {

    const uid = this.firebaseService.user.uid;
    const bgl: BloodGlucoseLevel = {
      userId: uid,
      value: value,
      timeStamp: Date.now()
    };
    this.firebaseService.afd.list('/bloodGlucoseLevel').push(bgl)
      .then((data) => {
        this.showBasicToast('Success! bgl value has been added!')
      }, (err) => {
        this.showBasicToast('Please make sure only type in numerical values');
      });
  }

  addBglByHand() {
    if (this.firebaseService.user) {
      let prompt = this.alertCtrl.create({
        title: 'Add Blood Glucose Value',
        message: 'Enter the blood glucose value below',
        inputs: [
          {
            name: 'value',
            placeholder: 'ml/dl'
          }
        ],
        buttons: [
          {
            text: 'Cancel'
          },
          {
            text: 'Confirm',
            handler: data => {
              if (data.value) {
                try { // test if the input contains only numerical values
                  const value = parseFloat(data.value);
                  this.addBgl(value);
                  return true;
                }
                catch (e) {
                  this.showBasicToast(e);
                  return false;
                }
              } else {
                return false;
              }

            }
          }
        ]
      });
      prompt.present();
    }
  }

  showBasicAlert(title, text) {
    const alert = this.alertCtrl.create({
      title: title,
      subTitle: text,
      buttons: ['OK']
    });
    alert.present();
  }

  showBasicToast(message: any) {
    let toast = this.toastCtrl.create({
      message: message,
      duration: 2000,
      position: 'bottom'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  // -----------------------------------------------------------
  // ---------------------save for real device------------------

  scan() {
    const duration = 5000;
    this.setStatus('Scanning for glucose meter (Smico GL)...');
    this.devices = [];  // clear list
    this.ble.scan([], duration / 1000).subscribe(
      device => this.onDeviceDiscovered(device),
      error => this.scanError(error)
    );

    // setTimeout(this.setStatus.bind(this), duration, 'Scan complete');
    setTimeout(() => {
      if (this.devices.length) {
        this.devices = this.devices.filter(d => {
          return d.name === 'Samico GL'
        });

        if (this.devices.length) {
          this.devices = _.sortBy(this.devices, 'rssi').reverse();
          this.setStatus('Found Samico GL glucose meter, setting up connection now...')
          const targetedDevice = this.devices[0];
          this.ble.connect(targetedDevice.id).subscribe(
            peripheral => this.onConnected(peripheral),
            peripheral => this.onDeviceDisconnected(peripheral)
          )
        } else {
          this.setStatus('Didn\'t find Samico GL glucose meter')
        }

      } else {
        this.setStatus('Didn\'t find any devices')
      }
    }, duration)
  }

  onConnected(peripheral) {
    this.openConnectDetailPage(peripheral);
  }

  onDeviceDisconnected(peripheral) {
    // let toast = this.toastCtrl.create({
    //   message: 'The peripheral unexpectedly disconnected',
    //   duration: 3000,
    //   position: 'middle'
    // });
    // toast.present();
    this.navCtrl.setRoot('ConnectPage');
    this.setStatus('Glucose meter disconnected');
  }

  onDeviceDiscovered(device) {
    console.log('Discovered ' + JSON.stringify(device, null, 2));
    this.ngZone.run(() => {
      this.devices.push(device);
    });
  }

  // If location permission is denied, you'll end up here
  scanError(error) {
    this.setStatus('Error ' + error);
    let toast = this.toastCtrl.create({
      message: 'Error scanning for glucose meter (Smico GL)',
      position: 'middle',
      duration: 5000
    });
    toast.present();
  }

  setStatus(message) {
    console.log(message);
    this.ngZone.run(() => {
      this.statusMessage = message;
      this.showBasicToast(message);
    });
  }

  openConnectDetailPage(peripheral) {
    console.log(JSON.stringify(peripheral) + ' connected');
    this.navCtrl.push('ConnectDetailPage', {
      peripheral: peripheral
    });
  }

  // -----------------------------------------------------------
  // -----------------------------------------------------------

  ionViewDidLoad(){
    this.result = null;
  }
}
