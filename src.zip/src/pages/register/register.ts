import {Component} from '@angular/core';
import {IonicPage, LoadingController, Loading, AlertController, NavController, NavParams} from 'ionic-angular';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {FirebaseServiceProvider} from "../../providers/firebase-service/firebase-service";
import {EmailValidator} from "../../validators/email";
import {PasswordValidator} from "../../validators/password";


@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  signupForm: FormGroup;
  loading: Loading;

  constructor(public navCtrl: NavController, public navParams: NavParams,
              private fb: FormBuilder,
              public firebaseService: FirebaseServiceProvider,
              public loadingCtrl: LoadingController,
              public alertCtrl: AlertController) {
    this.signupForm = this.fb.group(
      {
        name: ['', Validators.compose([Validators.required, Validators.minLength(2)])],
        email: ['', Validators.compose([Validators.required, EmailValidator.isValid])],
        password: ['', Validators.compose([Validators.required, Validators.minLength(6)])],
        passwordConfirm: ['', Validators.compose([Validators.required])]
      }, {
        validator: PasswordValidator.MatchPassword // match password
      }
    );
  }

  signupUser() {
    if (this.signupForm.valid) {
      this.loading = this.loadingCtrl.create();
      this.loading.present();

      this.firebaseService.signUp(this.signupForm.get('email').value,
        this.signupForm.get('password').value, this.signupForm.get('name').value)
        .then(() => {
          this.loading.dismiss().then(() => {
            this.navCtrl.setRoot('LoginPage');
          });
        }, (error) => {
            console.log(error)
            this.loading.dismiss().then(() => {
              let alert = this.alertCtrl.create({
                title: 'Error',
                message: error.message,
                buttons: [{
                  text: 'OK',
                  role: 'cancel'
                }]
              });
              alert.present();
            })
          });
    }
  }

}
