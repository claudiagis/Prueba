import {Component} from '@angular/core';
import {AlertController, IonicPage, Loading, LoadingController, NavController, NavParams} from 'ionic-angular';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {FirebaseServiceProvider} from "../../providers/firebase-service/firebase-service";
import {EmailValidator} from "../../validators/email";

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  signinForm: FormGroup;
  loading: Loading;

  constructor(public navCtrl: NavController, public navParams: NavParams,
              private fb: FormBuilder,
              public firebaseService: FirebaseServiceProvider,
              public loadingCtrl: LoadingController,
              public alertCtrl: AlertController) {
    this.signinForm = this.fb.group(
      {
        email: ['', Validators.compose([Validators.required, EmailValidator.isValid])],
        password: ['', Validators.compose([Validators.required, Validators.minLength(6)])],
      }
    );
  }

  loginUser() {
    if (this.signinForm.valid) {
      this.loading = this.loadingCtrl.create();
      this.loading.present();

      this.firebaseService.signIn(this.signinForm.get('email').value,
        this.signinForm.get('password').value).then((data) => {
        this.loading.dismiss();

      }, (error) => {
        this.loading.dismiss().then(() => {
          let alert = this.alertCtrl.create({
            title: 'Error',
            message: error.message,
            buttons: [
              {
                text: 'OK',
                role: 'cancle'
              }
            ]
          });
          alert.present();
        })
      });
    }
  }

  goToSignup() {
    this.navCtrl.push('RegisterPage');
  }

  resetPassword() {
    let prompt = this.alertCtrl.create({
      title: 'Reset Password',
      message: 'Enter your email below',
      inputs: [
        {
          name: 'email',
          placeholder: 'john@doe.com'
        }
      ],
      buttons: [
        {
          text: 'Cancel'
        },
        {
          text: 'Reset',
          handler: data => {
            this.firebaseService.resetPassword(data.email)
              .then(data => {
                this.showBasicAlert('Success', 'Check your email for further instructions');
              })
              .catch(err => {

                this.showBasicAlert('Failed', err.message);
              });
          }
        }
      ]
    })
    prompt.present();
  }

  showBasicAlert(title, text) {
    const alert = this.alertCtrl.create({
      title: title,
      subTitle: text,
      buttons: ['OK']
    });
    alert.present();
  }
}
