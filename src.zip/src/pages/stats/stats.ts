import {Component} from '@angular/core';
import {IonicPage, NavController, NavParams} from 'ionic-angular';
import {FirebaseServiceProvider} from "../../providers/firebase-service/firebase-service";
import {BloodGlucoseLevel} from "../../models/bloodGlucoseLevel";
import {Subscription} from "rxjs/Subscription";
import * as moment from 'moment';
import * as _ from 'lodash';


@IonicPage()
@Component({
  selector: 'page-stats',
  templateUrl: 'stats.html',
})
export class StatsPage {
  private subscriptions = [];
  bgls;
  constructor(public navCtrl: NavController, public navParams: NavParams,
              public firebaseService: FirebaseServiceProvider) {
  }

  ionViewDidLoad() {
    if (this.firebaseService.user) {
      const listRef = this.firebaseService.afd.list<BloodGlucoseLevel>('/bloodGlucoseLevel',
        ref => ref.orderByChild('userId').equalTo(this.firebaseService.user.uid));
      this.subscriptions.push(listRef.valueChanges().subscribe((data) => {
        const time = _.uniq(data.map((d:BloodGlucoseLevel)=> moment(d.timeStamp).format('DD MM YYYY')));
        const value = time.map((d:string) =>{
          const tempData = data.filter((e:BloodGlucoseLevel)=>moment(e.timeStamp).format('DD MM YYYY')===d)
          return _.sortBy(tempData,['timeStamp']).reverse()[0]
        });
        this.bgls = value.map((d: BloodGlucoseLevel)=>{
          return {date: moment(d.timeStamp), value: d.value};
        })
        console.log(this.bgls);
      }));
    }
  }

  ionViewWillUnload() {
    this.subscriptions.forEach((s: Subscription) => s.unsubscribe());
    console.log('subscription canceled!')
  }

  signOut() {
    this.firebaseService.signOut().then(() => {
      this.navCtrl.setRoot('LoginPage');
    })
  }

}
