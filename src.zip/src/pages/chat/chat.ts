import {Component, ViewChild} from '@angular/core';
import {IonicPage, NavController, NavParams, AlertController, ToastController, Content} from 'ionic-angular';
import {FirebaseServiceProvider} from "../../providers/firebase-service/firebase-service";
import {Chat} from "../../models/chat";
import {Subscription} from "rxjs/Subscription";

/**
 * Generated class for the ChatPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-chat',
  templateUrl: 'chat.html',
})
export class ChatPage {

  myWords = '';
  subscriptions = [];
  messages: Chat[];
  @ViewChild(Content) private content: Content;
  constructor(public navCtrl: NavController, public navParams: NavParams,
              public firebaseService: FirebaseServiceProvider,
              public alertCtrl: AlertController,
              public toastCtrl: ToastController) {
  }

  ionViewDidLoad() {
    if (this.firebaseService.user) {
      this.firebaseService.afd.list('/chat').push({
        specialMessage: true,
        content: `${this.firebaseService.userName} has joined the room`,
        userId: this.firebaseService.user.uid,
        userName: this.firebaseService.userName,
        timeStamp: Date.now()
      });
      const listRef = this.firebaseService.afd.list<Chat>('chat');
      this.subscriptions.push(listRef.valueChanges().subscribe((data) => {
        this.messages = data;
        setTimeout(() => {
          this.content.scrollToBottom();
        }, 50);
      }))
    }
  }

  ionViewDidEnter() {
    setTimeout(()=>{
      this.content.scrollToBottom();
    }, 50);
  }

  ionViewWillUnload() {
    this.subscriptions.forEach((s: Subscription) => s.unsubscribe());
    console.log('subscription canceled!')
  }

  ionViewWillLeave(){
    console.log('user is about to leave the chat room');
    if (this.firebaseService.user) {
      this.firebaseService.afd.list('/chat').push({
        specialMessage: true,
        content: `${this.firebaseService.userName} has left the room`,
        userId: this.firebaseService.user.uid,
        userName: this.firebaseService.userName,
        timeStamp: Date.now()
      });
    }
  }

  signOut() {
    this.firebaseService.signOut().then(() => {
      this.navCtrl.setRoot('LoginPage');
    })
  }

  showBasicAlert(title, text) {
    const alert = this.alertCtrl.create({
      title: title,
      subTitle: text,
      buttons: ['OK']
    });
    alert.present();
  }

  showBasicToast(message: any) {
    let toast = this.toastCtrl.create({
      message: message,
      duration: 2000,
      position: 'bottom'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  addChat() {
    if (this.firebaseService.user) {
      const uid = this.firebaseService.user.uid;
      if (this.myWords !== '') {
        const chat: Chat = {
          userId: uid,
          userName: this.firebaseService.userName,
          content: this.myWords,
          timeStamp: Date.now()
        };
        this.firebaseService.afd.list('/chat')
          .push(chat)
          .then(() => {
            this.myWords = '';
          }, () => {
            this.myWords = '';
          });
      } else {
        this.showBasicAlert('Empty Message!', 'please specify your message');
      }
    }

  }


}
