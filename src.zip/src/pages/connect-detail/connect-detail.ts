import {Component, NgZone} from '@angular/core';
import {AlertController, IonicPage, NavController, NavParams, ToastController} from 'ionic-angular';
import {ConnectGlucoseMeterProvider} from "../../providers/connect-glucose-meter/connect-glucose-meter";
import {BLE} from "@ionic-native/ble";

/**
 * Generated class for the ConnectDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-connet-detail',
  templateUrl: 'connect-detail.html',
})
export class ConnectDetailPage {
  peripheral: any = {};
  statusMessage: string;
  bloodGlucoseLevel: any; // mg/dl
  constructor(public navCtrl: NavController, public navParams: NavParams,
              public connectService: ConnectGlucoseMeterProvider,
              public alertCtrl: AlertController,
              public toastCtrl: ToastController,
              public ble: BLE,
              public ngZone: NgZone) {
    this.peripheral = navParams.get('peripheral');
    this.onReading(this.peripheral);

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ConnectDetailPage');
  }

  showBasicAlert(title, text) {
    const alert = this.alertCtrl.create({
      title: title,
      subTitle: text,
      buttons: ['OK']
    });
    alert.present();
  }

  showBasicToast(message: any) {
    let toast = this.toastCtrl.create({
      message: message,
      duration: 2000,
      position: 'bottom'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  onReading(peripheral) {

    this.ble.startNotification(peripheral.id, 'fff0', 'fff4').subscribe(buffer=>{
      this.ngZone.run(()=>{
        const data = new Uint8Array(buffer);
        const convertData = String.fromCharCode.apply(null, data);
        const hexResult = [];
        for ( let i = 0; i < convertData.length; i++) {

          const resultNumber = convertData.charCodeAt(i);   //Dec
          const str = (+resultNumber).toString(16);
          let resultString: string = "";
          if (str.length <= 1) {
            resultString = ("0" + (+resultNumber).toString(16)).toUpperCase().substring(-2); //String
          } else {
            resultString = ("" + (+resultNumber).toString(16)).toUpperCase().substring(-2); //String
          }

          hexResult[i] = resultString;

        }

        const hexString = "0x" + hexResult.join('');

        this.bloodGlucoseLevel = (hexString as any) >> 16;
        this.connectService.setBglValue(this.bloodGlucoseLevel);
        this.setStatus('Successfully read result');
        this.navCtrl.pop();
      });
    });

  }


  // Disconnect peripheral when leaving the page
  ionViewWillLeave() {
    console.log('ionViewWillLeave disconnecting Bluetooth');
    this.ble.disconnect(this.peripheral.id).then(
      () => console.log('Disconnected ' + JSON.stringify(this.peripheral)),
      () => console.log('ERROR disconnecting ' + JSON.stringify(this.peripheral))
    )
  }


  setStatus(message) {
    console.log(message);
    this.ngZone.run(() => {
      this.statusMessage = message;
      this.showBasicToast(message);
    });
  }

}
