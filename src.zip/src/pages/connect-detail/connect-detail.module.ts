import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConnectDetailPage } from './connect-detail';

@NgModule({
  declarations: [
    ConnectDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(ConnectDetailPage),
  ],
})
export class ConnetDetailPageModule {}
