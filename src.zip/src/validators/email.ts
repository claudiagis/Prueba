import {AbstractControl} from '@angular/forms';

export class EmailValidator {

  static isValid(control: AbstractControl) {
    const re = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/.test(control.value);

    // success
    if (re) {
      return null;
    }

    return {"invalidEmail": true};
  }
}

